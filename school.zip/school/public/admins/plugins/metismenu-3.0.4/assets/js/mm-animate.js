$(function () {

    $('#menu').metisMenu();

});
